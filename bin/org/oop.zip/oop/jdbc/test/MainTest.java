package org.oop.jdbc.test;

import org.oop.jdbc.pojo.Dosen;
//import org.oop.jdbc.utils.DatabaseUtil;

import com.oop.jdbc.dao.DosenDAOImpl;
import com.oop.jdbc.daoimpl.DosenDAO;

public class MainTest {
	public static void main(String[] args) {
		//DatabaseUtil db = new DatabaseUtil();
		
		//db.connect();
		
		DosenDAO operation = new DosenDAOImpl();
		Dosen dosen = new Dosen();
		
		/*
		for(Dosen dosen : operation.getAllDosen()) {
			System.out.println("NIP : " +dosen.getNip());
			System.out.println("Nama : "+dosen.getNama());
			System.out.println("Email : "+dosen.getEmail());
		}*/
		
		dosen.setNip(162020035);
		dosen.setNama("Yusup");
		dosen.setEmail("syalala@gmail.com");
		
		operation.saveDosen(dosen);
	}
}
