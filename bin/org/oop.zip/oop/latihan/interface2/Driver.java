package org.oop.latihan.interface2;

public class Driver {
	public static void main(String[] args) {
		Lingkaran lingkaran = new Lingkaran("Lingkaran", "Merah", 7.0);
		System.out.println(lingkaran.infoLingkaran());
	}
}
