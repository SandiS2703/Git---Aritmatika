package org.oop.latihan.classrelationship.agregation;

public class Dosen {

}
