package org.oop.latihan.interface2;

interface LingkaranInterface {
	double luas();
	double keliling();
	String infoLingkaran();
}
