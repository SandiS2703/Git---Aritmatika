package org.oop.latihan.kopi;

abstract class AbstractKopi {
	
	abstract void komposisi();
	abstract double total();
}
